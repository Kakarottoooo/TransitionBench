"""Plan-driven real single-GPU restart trials. No simulated transition traffic."""
import asyncio
from dataclasses import asdict, replace
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent.parent

async def metrics_snapshot(base,path):
    try:
        async with httpx.AsyncClient(timeout=5,trust_env=False) as client:
            response=await client.get(base+'/metrics')
            response.raise_for_status()
            path.write_text(response.text)
    except Exception as exc:
        path.with_suffix('.error.json').write_text(json.dumps(dict(error=type(exc).__name__+': '+str(exc))))

def workload(plan, trial):
    rows=[]
    offset=0.0
    for phase_index, phase in enumerate(trial['phases']):
        phase_spec=WorkloadSpec(kind=phase['kind'],long_prefix_mode=phase.get('prefix','unique'),seed=trial['seed']*10+phase_index,
            split=trial['split'],rate_rps=phase['rate'],injection_s=phase['duration_s'])
        for item in generate(phase_spec):
            rows.append(replace(item,scheduled_s=round(item.scheduled_s+offset,9)))
        offset+=phase['duration_s']
    return rows,offset

def decision_after_history(history, plan):
    """Only already observed arrivals enter this function; no future phase access."""
    if len(history)<8:
        return False
    recent=history[-8:]
    kind='long' if plan['target_condition']['kind']=='long-prefix' else 'short'
    duration=recent[-1][0]-recent[0][0]
    rate=7/duration if duration>0 else 0
    matched=all(x[1]==kind for x in recent) and abs(rate-plan['target_condition']['rate']) <= .05*plan['target_condition']['rate']
    if plan['target_condition'].get('prefix')=='shared':
        matched &= len(history)>=16 and len({x[2] for x in history[-16:]})<=4
    return matched

async def trial_run(plan, trial, out, runtime, state, save):
    name=trial['name']
    initial=plan['target'] if trial['policy']=='candidate_reference' else plan['source']
    await runtime.start_engine(name+'-initial',initial,ENV)
    offered,injection=workload(plan,trial)
    reserved=sum(x.input_token_upper_bound+32 for x in offered)
    if len(offered)>20000 or reserved>20000000:
        raise ValueError('Plan exceeds the explicit request/token budget; no truncation permitted')
    spec=ExperimentSpec(mode='LIVE_ENDPOINT',endpoint_id='local-decision',policy={
        'keep':'StaticBest','candidate_reference':'StaticBest','immediate':'SteadyStateFirst',
        'forced':'SteadyStateFirst','cost_aware':'StateAware','hysteresis':'FixedHysteresis'}[trial['policy']],
        workload=WorkloadSpec(kind='mixed-burst',long_prefix_mode='unique',seed=trial['seed'],split=trial['split'],
                              rate_rps=plan['target_condition']['rate'],injection_s=injection),
        observation_s=injection+10,drain_s=10,budget=ResourceBudget(max_requests=len(offered),max_total_tokens=reserved,
            max_output_tokens=32,max_concurrency=128,max_duration_s=injection+10,reserved_gpus=1,max_reserved_gpu_seconds=injection+10))
    endpoint=EndpointClient(EndpointSpec(id='local-decision',base_url=runtime.BASE+'/v1',model=runtime.NAME,
        streaming=True,temperature=0,seed=0,timeout_s=25,supported_parameters=['max_tokens','stream','temperature','seed']),
        NetworkPolicy([runtime.BASE],['127.0.0.1']))
    await endpoint.discover()
    await metrics_snapshot(runtime.BASE,out/(name+'-metrics-before.txt'))
    raw_workload=''.join(json.dumps(asdict(x))+'\n' for x in offered)
    (out/(name+'-offered.jsonl')).write_text(raw_workload)
    events=[]
    decisions=[]
    failures=[]
    oldmeasure=endpoint.measure
    def capture(item,row,content):
        if len(failures)<32:
            failures.append(dict(request_id=item.request_id,expected=item.expected,actual=content[:256],chars=len(content)))
    async def measure(*args,**kwargs):
        return await oldmeasure(*args,**kwargs,on_quality_failure=capture)
    endpoint.measure=measure
    epoch=time.monotonic()
    history=[]
    advantage_since=None
    switching=None
    inflight=0

    async def switch():
        events.append(dict(worker_id='local-0',state='STOPPING',at_s=time.monotonic()-epoch))
        save(name+'-transition.json',events)
        try:
            # Process waits run off the dispatch event loop. Offered traffic never pauses.
            await asyncio.to_thread(runtime.stop_owned,runtime.server)
            runtime.server=None
            events.append(dict(worker_id='local-0',state='STARTING',at_s=time.monotonic()-epoch))
            await runtime.start_engine(name+'-replacement',plan['target'],ENV)
            events.append(dict(worker_id='local-0',state='COMPLETE',at_s=time.monotonic()-epoch))
        except Exception as exc:
            events.append(dict(worker_id='local-0',state='FAILED',at_s=time.monotonic()-epoch,error=type(exc).__name__+': '+str(exc)))
        finally:
            save(name+'-transition.json',events)

    def arrival(kind,prefix,at_s,pending):
        nonlocal advantage_since,switching,inflight
        inflight=pending
        history.append((at_s,kind,prefix))
        if len(history)>64:
            del history[:-64]
        if switching is not None or trial['policy'] in ('keep','candidate_reference'):
            return
        if trial['policy']=='forced':
            eligible=at_s>=trial['switch_at_s']
        else:
            advantage=decision_after_history(history,plan)
            if not advantage:
                advantage_since=None
                return
            if advantage_since is None:
                advantage_since=at_s
            patience=0 if trial['policy']=='immediate' else plan['persistence_s']
            eligible=at_s-advantage_since>=patience
        if not eligible:
            return
        if trial['policy']=='cost_aware':
            decision=evaluate_decision(DecisionInput(current_goodput_rps=plan['calibration']['source_rate'],
                candidate_goodput_rps=plan['calibration']['target_rate'],horizon_s=plan['forecast_horizon_s'],
                transition_deficit_requests=plan['calibration']['loss_upper'],uncertainty_requests=0,
                min_gain_requests=plan['minimum_gain_requests'],evidence_ids=plan['calibration']['evidence_ids'],
                state_known=True,origin='measured-black-box'))
            decisions.append(dict(at_s=at_s,queue_depth=pending,**decision.model_dump(mode='json')))
            if decision.action!='SWITCH':
                return
        else:
            decisions.append(dict(at_s=at_s,queue_depth=pending,action='SWITCH',policy=trial['policy']))
        switching=asyncio.create_task(switch())

    rows,validity=await run_endpoint(spec,endpoint,asyncio.Event(),offered=offered,on_arrival=arrival,epoch=epoch,skip_discovery=True)
    await asyncio.sleep(max(0,spec.observation_s-(time.monotonic()-epoch)))
    if switching and not switching.done():
        # Do not extend the scoring horizon to make a transition look successful.
        switching.cancel()
        await asyncio.gather(switching,return_exceptions=True)
        validity['valid']=False
        validity['errors'].append('Transition not completed within observation horizon')
    if any(e['state']=='FAILED' for e in events):
        validity['valid']=False;validity['errors'].append('Deployment process failed; all offered traffic retained')
    await metrics_snapshot(runtime.BASE,out/(name+'-metrics-after.txt'))
    save(name+'-failures.json',failures)
    save(name+'-transition.json',events)
    save(name+'-decisions.json',decisions)
    manifest=RunManifest(run_id=name,mode='LIVE_ENDPOINT',origin='measured-black-box',experiment=spec,
        offered_ids=[r.request_id for r in rows],created_at_unix_s=time.time(),
        versions=dict(code_revision=CODE_REVISION,engine='vLLM 0.6.4.post1',model_revision=Path(runtime.MODEL).name),
        configurations=plan.get('configurations',{c:dict(max_num_batched_tokens=v,max_num_seqs=32) for c,v in runtime.CONFIGS.items()}),
        policy_parameters=dict(endpoint_contract=endpoint.spec.model_dump(mode='json'),initial_config=initial,
            trial=trial,protocol_sha256=PLAN_HASH,offered_sha256=hashlib.sha256(raw_workload.encode()).hexdigest(),
            local_restart_scope='One GPU, restart deployment with ongoing offered traffic; not two-worker controlled rollout'),
        resource_intervals=[dict(start_s=0,end_s=spec.observation_s,reserved_gpus=1,active_gpu_seconds=None)])
    summary=export_bundle(out/name,manifest,rows,events,decisions,validity)
    verified=verify_bundle(out/name)
    save(name+'-verification.json',verified)
    return dict(name=name,qualified=summary['qualified'],offered=summary['offered'],
        policy=trial['policy'],seed=trial['seed'],scenario=trial['scenario'],
        valid=verified['integrity_valid'] and verified['experiment_valid'],transitions=events)

async def main(plan,out,runtime,state,save):
    with socket.socket() as probe:
        if probe.connect_ex(('127.0.0.1',18870)) == 0:
            raise RuntimeError('Port occupied by another process; leave it untouched')
    for trial in plan['trials']:
        state.update(state='RUNNING',current=trial['name']);save('status.json',state)
        try:
            result=await trial_run(plan,trial,out,runtime,state,save)
            state['completed'].append(result)
            print(json.dumps(result),flush=True)
        except Exception as exc:
            state['failures'].append(dict(name=trial['name'],error=type(exc).__name__+': '+str(exc)))
            print(json.dumps(state['failures'][-1]),flush=True)
        finally:
            await asyncio.to_thread(runtime.stop_owned,runtime.server);runtime.server=None
            save('status.json',state)
            await asyncio.sleep(3)
    state['state']='COMPLETE' if len(state['completed'])==len(plan['trials']) and not state['failures'] else 'PARTIAL'

if __name__=='__main__':
    planfile=Path(sys.argv[1]).resolve()
    plan=json.loads(planfile.read_text())
    out=ROOT/'outputs/transitionbench/reports'/plan['id'];out.mkdir(exist_ok=False)
    shutil.copyfile(planfile,out/'protocol.json')
    shutil.copyfile(__file__,out/'supervisor.py')
    producer=out/'producer/transitionbench';producer.mkdir(parents=True)
    digest=hashlib.sha256()
    source=ROOT/plan.get('producer_snapshot','outputs/transitionbench/src/transitionbench')
    if not source.resolve().is_relative_to((ROOT/'outputs/transitionbench').resolve()) or not (source/'endpoint.py').is_file():
        raise ValueError('Producer snapshot must be an existing TransitionBench source directory')
    for p in sorted(source.glob('*.py')):
        digest.update(p.name.encode());digest.update(p.read_bytes());shutil.copyfile(p,producer/p.name)
    CODE_REVISION='sha256:'+digest.hexdigest()
    PLAN_HASH=hashlib.sha256((out/'protocol.json').read_bytes()).hexdigest()
    sys.path.insert(0,str(producer.parent))
    import httpx
    from transitionbench.endpoint import EndpointClient,NetworkPolicy,run_endpoint
    from transitionbench.schemas import EndpointSpec,ExperimentSpec,ResourceBudget,RunManifest,WorkloadSpec,DecisionInput
    from transitionbench.workloads import generate
    from transitionbench.evidence import export_bundle
    from transitionbench.verifier import verify_bundle
    from transitionbench.policy import evaluate_decision
    # Reuse the exact frozen discovery startup implementation; no second engine launcher.
    helper=ROOT/'outputs/transitionbench/reports/local-decision-discovery-v1/supervisor.py'
    shutil.copyfile(helper,out/'engine-runtime.py')
    loader=importlib.util.spec_from_file_location('engine_runtime',helper)
    runtime=importlib.util.module_from_spec(loader);loader.loader.exec_module(runtime)
    runtime.OUT=out;runtime.httpx=httpx
    if 'configurations' in plan:
        runtime.CONFIGS={c:v['max_num_batched_tokens'] for c,v in plan['configurations'].items()}
        original_args=runtime.config_args
        def planned_args(config):
            args=original_args(config)
            if not plan['configurations'][config]['prefix_caching']:
                args.remove('--enable-prefix-caching')
            return args
        runtime.config_args=planned_args
    if plan.get('record_prestart_resources'):
        original_start = runtime.start_engine
        async def observed_start(name, config, env):
            def snapshot():
                commands = {
                    'gpu': ['nvidia-smi','--query-gpu=memory.used,memory.free,utilization.gpu','--format=csv,noheader,nounits'],
                    'processes': ['ps','-eo','pid,ppid,pgid,comm']}
                data = dict(at_unix_s=time.time(),name=name,config=config)
                for label, command in commands.items():
                    probe = subprocess.run(command,capture_output=True,text=True,timeout=5)
                    data[label] = dict(exit_code=probe.returncode,stdout=probe.stdout,stderr=probe.stderr)
                (out/(name+'-prestart-resources.json')).write_text(json.dumps(data,indent=2))
            await asyncio.to_thread(snapshot)
            return await original_start(name,config,env)
        runtime.start_engine=observed_start
    ENV=dict(os.environ,HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',VLLM_NO_USAGE_STATS='1',DO_NOT_TRACK='1')
    for key,folder in [('TMPDIR','/dev/shm/tb-decision'),('XDG_CACHE_HOME','cache'),('TRITON_CACHE_DIR','triton'),
                       ('TORCHINDUCTOR_CACHE_DIR','inductor'),('CUDA_CACHE_PATH','cuda')]:
        path=Path(folder) if folder.startswith('/') else ROOT/'work/local-prefix-runtime'/folder
        path.mkdir(parents=True,exist_ok=True);ENV[key]=str(path)
    def save(name,value):
        (out/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
    def interrupt(*_):
        raise KeyboardInterrupt('Local runtime budget reached')
    signal.signal(signal.SIGTERM,interrupt);signal.signal(signal.SIGALRM,interrupt);signal.alarm(plan['max_runtime_s'])
    with (out/'gpu.csv').open('w') as log:
        sampler=subprocess.Popen(['nvidia-smi','--query-gpu=timestamp,uuid,utilization.gpu,memory.used,power.draw,clocks.sm',
            '--format=csv,noheader,nounits','--loop-ms=1000'],stdout=log,stderr=subprocess.DEVNULL,start_new_session=True)
    state=dict(state='PREPARING',started_unix_s=time.time(),planned=len(plan['trials']),completed=[],failures=[],cloud_gpu_spend_usd=0)
    save('status.json',state)
    try:
        asyncio.run(main(plan,out,runtime,state,save))
    except BaseException as exc:
        state.update(state='PARTIAL',fatal_error=type(exc).__name__+': '+str(exc))
    finally:
        runtime.stop_owned(runtime.server);runtime.stop_owned(sampler);signal.alarm(0)
        state.update(ended_unix_s=time.time(),owned_processes_stopped=True)
        save('status.json',state)
