"""TransitionBench's CPU-only analysis and experiment core."""

__version__ = "0.3.1"
