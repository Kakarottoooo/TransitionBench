"""Local discovery for a measured deployment decision; no cloud actions."""
import asyncio
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'outputs/transitionbench/reports/local-decision-discovery-v1'
MODEL = '/home/kakarotto/.cache/huggingface/hub/models--Qwen--Qwen2.5-7B-Instruct-GPTQ-Int4/snapshots/e9c932ac1893a49ae0fc497ad6e1e86e2e39af20'
BASE = 'http://127.0.0.1:18870'
NAME = 'transitionbench-local-qwen7b-int4'
CONFIGS = {'A': 512, 'B': 4096}
CONDITIONS = [('short', 16), ('short', 32), ('short', 64), ('long-prefix', 4), ('long-prefix', 8), ('long-prefix', 16)]
# Balanced A-B / B-A order; no cell is retried or removed on poor performance.
BLOCKS = [(7501, 'A'), (7501, 'B'), (7502, 'B'), (7502, 'A')]
server = sampler = None
state = {}

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')

def stop_owned(process):
    if process is None:
        return
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    try:
        process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        process.wait(timeout=10)
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass

def interrupt(*_):
    raise KeyboardInterrupt('Local supervisor deadline or cancellation')

def config_args(config):
    return [sys.executable, '-m', 'vllm.entrypoints.openai.api_server', '--host', '127.0.0.1', '--port', '18870',
            '--model', MODEL, '--served-model-name', NAME, '--dtype', 'half', '--max-model-len', '4096',
            '--gpu-memory-utilization', '.65', '--max-num-seqs', '32', '--max-num-batched-tokens',
            str(CONFIGS[config]), '--enable-prefix-caching', '--enable-chunked-prefill',
            '--disable-log-requests', '--swap-space', '0']

async def start_engine(name, config, env):
    global server
    started = time.monotonic()
    args = config_args(config)
    with (OUT / (name + '-engine.log')).open('w') as log:
        server = subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT, env=env, start_new_session=True)
    save(name + '-process.json', dict(pid=server.pid, command=args, started_unix_s=time.time()))
    async with httpx.AsyncClient(timeout=3, trust_env=False) as client:
        while time.monotonic() - started < 180:
            if server.poll() is not None:
                raise RuntimeError('Engine exited; see retained engine log')
            try:
                if (await client.get(BASE + '/health')).status_code == 200:
                    break
            except httpx.HTTPError:
                pass
            await asyncio.sleep(1)
        else:
            raise TimeoutError('Engine startup exceeded 180 seconds')
        # Fixed preparation, never wait until a favorable stable window appears.
        warm = time.monotonic()
        probes = []
        while time.monotonic() - warm < 20:
            expected = 'TB-WARM:4'
            before = time.monotonic()
            response = await client.post(BASE + '/v1/chat/completions', json=dict(model=NAME,
                messages=[dict(role='user', content='Return exactly TB-WARM:4 and nothing else.')],
                temperature=0, seed=0, max_tokens=32))
            obj = response.json() if response.status_code == 200 else {}
            choices = obj.get('choices', [])
            content = choices[0]['message'].get('content', '') if choices else ''
            probes.append(dict(start_s=before-warm, end_s=time.monotonic()-warm, status=response.status_code,
                valid=bool(choices and choices[0].get('finish_reason') == 'stop' and content.strip() == expected),
                actual=content[:256], usage=obj.get('usage')))
        save(name + '-warmup.json', dict(duration_s=time.monotonic()-warm, probes=probes,
            startup_and_preparation_s=time.monotonic()-started,
            rule='Fixed 20 seconds. Latency drift and occasional invalid answers are retained, not a stop condition.'))
        if not any(p['status'] == 200 for p in probes):
            raise RuntimeError('No functional inference response during preparation')

async def measure(name, config, seed, kind, rate):
    spec = ExperimentSpec(mode='LIVE_ENDPOINT', endpoint_id='local-decision', policy='StaticBest',
        workload=WorkloadSpec(kind=kind, long_prefix_mode='unique', seed=seed, split='calibration',
                              rate_rps=rate, injection_s=15),
        observation_s=25, drain_s=10,
        budget=ResourceBudget(max_requests=1000,max_total_tokens=10000000,max_output_tokens=32,
                              max_concurrency=128,max_duration_s=60,reserved_gpus=1,max_reserved_gpu_seconds=60))
    endpoint = EndpointClient(EndpointSpec(id='local-decision', base_url=BASE+'/v1', model=NAME,
        streaming=True,temperature=0,seed=0,timeout_s=25,
        supported_parameters=['max_tokens','stream','temperature','seed']), NetworkPolicy([BASE],['127.0.0.1']))
    failures = []
    original = endpoint.measure
    def capture(item, row, text):
        if len(failures) < 32:
            failures.append(dict(request_id=item.request_id, expected=item.expected, actual=text[:256],
                                 chars=len(text), finish_reason=row.finish_reason))
    async def measured(*args, **kwargs):
        return await original(*args, **kwargs, on_quality_failure=capture)
    endpoint.measure = measured
    async with httpx.AsyncClient(timeout=5, trust_env=False) as client:
        before = await client.get(BASE+'/metrics')
        (OUT/(name+'-metrics-before.txt')).write_text(before.text)
    start = time.monotonic()
    rows, validity = await run_endpoint(spec, endpoint, asyncio.Event())
    await asyncio.sleep(max(0,25-(time.monotonic()-start)))
    save(name+'-failures.json', failures)
    manifest = RunManifest(run_id=name, mode='LIVE_ENDPOINT', origin='measured-black-box', experiment=spec,
        offered_ids=[r.request_id for r in rows], created_at_unix_s=time.time(),
        versions=dict(code_revision=CODE_REVISION,engine='vLLM 0.6.4.post1',model_revision=Path(MODEL).name),
        configurations={c:dict(max_num_batched_tokens=b,max_num_seqs=32) for c,b in CONFIGS.items()},
        policy_parameters=dict(endpoint_contract=endpoint.spec.model_dump(mode='json'),
            local_diagnostic_config=config,protocol_sha256=PROTOCOL_HASH),
        resource_intervals=[dict(start_s=0,end_s=25,reserved_gpus=1,active_gpu_seconds=None)])
    metrics = export_bundle(OUT/name,manifest,rows,[],[],validity)
    verified = verify_bundle(OUT/name)
    save(name+'-verification.json',verified)
    async with httpx.AsyncClient(timeout=5, trust_env=False) as client:
        after = await client.get(BASE+'/metrics')
        (OUT/(name+'-metrics-after.txt')).write_text(after.text)
    result = dict(name=name,config=config,seed=seed,kind=kind,rate=rate,
        qualified=metrics['qualified'],offered=metrics['offered'],terminations=metrics['terminations'],
        quality_valid=sum(r.quality_valid for r in rows),valid=validity['valid'],
        verified=verified['integrity_valid'] and verified['experiment_valid'])
    return result

async def main():
    global server, sampler
    with socket.socket() as probe:
        if probe.connect_ex(('127.0.0.1',18870)) == 0:
            raise RuntimeError('Port occupied; no unrelated process will be stopped')
    env = dict(os.environ, HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', VLLM_NO_USAGE_STATS='1', DO_NOT_TRACK='1')
    for key, folder in [('TMPDIR','/dev/shm/tb-decision'),('XDG_CACHE_HOME','cache'),('TRITON_CACHE_DIR','triton'),
                        ('TORCHINDUCTOR_CACHE_DIR','inductor'),('CUDA_CACHE_PATH','cuda')]:
        path = Path(folder) if folder.startswith('/') else ROOT/'work/local-prefix-runtime'/folder
        path.mkdir(parents=True,exist_ok=True)
        env[key] = str(path)
    with (OUT/'gpu.csv').open('w') as log:
        sampler=subprocess.Popen(['nvidia-smi','--query-gpu=timestamp,uuid,utilization.gpu,memory.used,power.draw,clocks.sm',
            '--format=csv,noheader,nounits','--loop-ms=1000'],stdout=log,stderr=subprocess.DEVNULL,start_new_session=True)
    for block, (base_seed, config) in enumerate(BLOCKS):
        name = f'block-{block}-{base_seed}-{config}'
        state.update(state='STARTING_ENGINE',current=name); save('status.json',state)
        try:
            await start_engine(name, config, env)
            for index in (range(len(CONDITIONS)) if base_seed == 7501 else reversed(range(len(CONDITIONS)))):
                kind, rate = CONDITIONS[index]
                seed = base_seed*10+index  # No cross-condition prefix reuse; matched across A/B.
                cell = f'{base_seed}-{config}-{kind}-{rate}'
                state.update(state='MEASURING',current=cell); save('status.json',state)
                try:
                    result = await measure(cell,config,seed,kind,rate)
                    state['completed'].append(result)
                    print(json.dumps(result),flush=True)
                except Exception as exc:
                    state['failures'].append(dict(name=cell,error=type(exc).__name__+': '+str(exc)))
                    print(json.dumps(state['failures'][-1]),flush=True)
                    if server.poll() is not None:
                        break
                save('status.json',state)
        except Exception as exc:
            state['failures'].append(dict(name=name,error=type(exc).__name__+': '+str(exc)))
            save('status.json',state)
        finally:
            stop_owned(server); server=None
            await asyncio.sleep(3)
    state['state']='DISCOVERY_COMPLETE' if len(state['completed']) == 24 and not state['failures'] else 'DISCOVERY_PARTIAL'

if __name__ == '__main__':
    OUT.mkdir(exist_ok=False)
    producer = OUT/'producer/transitionbench'
    producer.mkdir(parents=True)
    digest = hashlib.sha256()
    for path in sorted((ROOT/'outputs/transitionbench/src/transitionbench').glob('*.py')):
        digest.update(path.name.encode()); digest.update(path.read_bytes())
        shutil.copyfile(path,producer/path.name)
    shutil.copyfile(__file__,OUT/'supervisor.py')
    sys.path.insert(0,str(producer.parent))
    import httpx
    from transitionbench.endpoint import EndpointClient, NetworkPolicy, run_endpoint
    from transitionbench.schemas import EndpointSpec, ExperimentSpec, ResourceBudget, RunManifest, WorkloadSpec
    from transitionbench.evidence import export_bundle
    from transitionbench.verifier import verify_bundle
    CODE_REVISION='sha256:'+digest.hexdigest()
    started=time.time()
    save('protocol.json',dict(purpose='Exploratory capacity-shape discovery for subsequent held-out deployment decision tests',
        configurations=CONFIGS,max_num_seqs=32,blocks=BLOCKS,conditions=CONDITIONS,seed_mapping='base_seed*10+condition_index',
        model=MODEL,code_revision=CODE_REVISION,injection_s=15,observation_s=25,warmup_s=20,
        slope_rule='Descriptive only; select a load with nonzero qualified throughput and repeatable paired advantage for fresh-seed confirmation.',
        failure_rule='Quality/latency/ordinary desktop variation never stops the study. Invalid cells retained; transport/engine failures affect their block. No automatic cell retries.',
        scope='Same-model single-GPU service. No policy or crossover claim from this discovery. Config A 512 differs from old A 2048; do not pool.',
        order_control='A then B seed7501; B then A seed7502, reversed condition order. Different condition seeds prevent cache reuse across rates.',
        max_runtime_s=2100,stop_at_utc=datetime.fromtimestamp(started+2100,timezone.utc).isoformat(),cloud_gpu_spend_usd=0))
    PROTOCOL_HASH=hashlib.sha256((OUT/'protocol.json').read_bytes()).hexdigest()
    save('host.json',dict(packages={n:importlib.metadata.version(n) for n in ('vllm','torch','httpx','pydantic')},
        nvidia_smi=subprocess.run(['nvidia-smi'],capture_output=True,text=True,timeout=15).stdout))
    state=dict(state='PREPARING',started_unix_s=started,completed=[],failures=[],planned=24,cloud_gpu_spend_usd=0)
    save('status.json',state)
    signal.signal(signal.SIGTERM,interrupt);signal.signal(signal.SIGALRM,interrupt);signal.alarm(2100)
    try:
        asyncio.run(main())
    except BaseException as exc:
        state.update(state='DISCOVERY_PARTIAL',fatal_error=type(exc).__name__+': '+str(exc))
    finally:
        stop_owned(server);stop_owned(sampler);signal.alarm(0)
        state.update(ended_unix_s=time.time(),elapsed_s=time.time()-started,owned_processes_stopped=True)
        save('status.json',state)
        print(json.dumps(state),flush=True)
