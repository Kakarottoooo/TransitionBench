param([Parameter(Mandatory=$true)][string]$PlanName)
$ErrorActionPreference='Stop'
if ($PlanName -notmatch '^local-cache-(calibration|heldout|prospective|prospective-v2|prospective-v3|prospective-v4)-plan\.json$') {throw 'Unexpected experiment plan'}
$receipt=[ordered]@{plan=$PlanName;started_utc=[DateTimeOffset]::UtcNow.ToString('o');pause_command_sent=$false;resume_command_sent=$false}
$receiptPath=Join-Path $PSScriptRoot ($PlanName.Replace('-plan.json','-wallpaper.json'))
$resourceJob=$null
try {
    if ($PlanName -in @('local-cache-prospective-v2-plan.json','local-cache-prospective-v3-plan.json','local-cache-prospective-v4-plan.json')) {
        $game=Get-Process -Name 'DeadByDaylight-Win64-Shipping' -ErrorAction SilentlyContinue
        $used=[int]((& nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits | Select-Object -First 1).Trim())
        $receipt.preflight_memory_used_mib=$used
        $receipt.preflight_game_running=[bool]$game
        if ($PlanName -eq 'local-cache-prospective-v4-plan.json') {
            $unity=Get-Process -Name Unity -ErrorAction SilentlyContinue
            $receipt.preflight_unity_running=[bool]$unity
            if ($unity) {throw 'Unity is active; no engine launched. Leave user program untouched.'}
        }
        $receipt.preflight_limit_mib=2500
        if ($game -or $used -gt 2500) {throw 'GPU still contested before collection; no engine launched. Leave other applications untouched.'}
    }
    & 'E:\SteamLibrary\steamapps\common\wallpaper_engine\wallpaper64.exe' -control pause
    $receipt.pause_command_sent=$true
    $receipt|ConvertTo-Json|Set-Content $receiptPath -Encoding utf8
    if ($PlanName -eq 'local-cache-prospective-v4-plan.json') {
        $resourcePath=Join-Path $PSScriptRoot 'local-cache-prospective-v4-resources.jsonl'
        if (Test-Path -LiteralPath $resourcePath) {throw 'Do not overwrite an existing resource trace'}
        $resourceJob=Start-Job -ArgumentList $resourcePath -ScriptBlock {
            param($path)
            while ($true) {
                $samples=@(Get-Counter '\GPU Process Memory(*)\Dedicated Usage' -ErrorAction SilentlyContinue | ForEach-Object {$_.CounterSamples} | Where-Object CookedValue -GT 100000000 | ForEach-Object {
                    $taskPid=if($_.InstanceName -match '^pid_(\d+)_'){[int]$Matches[1]}else{0}
                    $taskProcess=Get-Process -Id $taskPid -ErrorAction SilentlyContinue
                    @{pid=$taskPid;name=$taskProcess.ProcessName;counter_bytes=$_.CookedValue}
                })
                @{utc=[DateTimeOffset]::UtcNow.ToString('o');gpu=((& nvidia-smi --query-gpu=memory.used,utilization.gpu --format=csv,noheader,nounits)-join ' ');process_samples=$samples;unity_present=[bool](Get-Process -Name Unity -ErrorAction SilentlyContinue)}|ConvertTo-Json -Depth 5 -Compress|Add-Content -LiteralPath $path -Encoding utf8
                Start-Sleep -Seconds 5
            }
        }
    }
    $linuxRoot='/mnt/e/CodexWorkspaces/projects/2026-09-19/files-pasted-by-the-user-codex/work'
    & wsl -d Ubuntu-48G -- /home/kakarotto/.venvs/tensorforge-vllm-064/bin/python "$linuxRoot/local-switch-study.py" "$linuxRoot/$PlanName"
    $receipt.runner_exit_code=$LASTEXITCODE
} finally {
    if ($null -ne $resourceJob) {Stop-Job $resourceJob; Remove-Job $resourceJob}
    & 'E:\SteamLibrary\steamapps\common\wallpaper_engine\wallpaper64.exe' -control play
    $receipt.resume_command_sent=$true
    $receipt.ended_utc=[DateTimeOffset]::UtcNow.ToString('o')
    $receipt|ConvertTo-Json|Set-Content $receiptPath -Encoding utf8
}
