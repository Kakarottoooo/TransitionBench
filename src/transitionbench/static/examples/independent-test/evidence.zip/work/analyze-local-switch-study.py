"""Independent standard-library verification of restart decisions and repayment."""
from bisect import bisect_right
import hashlib
import json
import math
from pathlib import Path
import statistics
import subprocess
import sys

ROOT=Path(__file__).resolve().parent.parent

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def qualified(row,spec):
    return (row['termination']=='complete' and row['quality_valid'] and row['output_chars']>0 and
        row['completed_s'] is not None and row['completed_s']<=spec['observation_s'] and row['first_content_s'] is not None and
        row['completed_s']-row['scheduled_s']<=spec['slo']['e2e_s'] and
        row['first_content_s']-row['scheduled_s']<=spec['slo']['first_content_s'])

def analyze(out):
    plan=read(out/'protocol.json')
    planhash=hashlib.sha256((out/'protocol.json').read_bytes()).hexdigest()
    digest=hashlib.sha256()
    for path in sorted((out/'producer/transitionbench').glob('*.py')):
        digest.update(path.name.encode());digest.update(path.read_bytes())
    sourcehash='sha256:'+digest.hexdigest()
    results=[]
    raw_by_name={}
    for trial in plan['trials']:
        name=trial['name'];folder=out/name
        result=dict(name=name,seed=trial['seed'],scenario=trial['scenario'],policy=trial['policy'],status='NOT_MEASURED')
        if (folder/'checksums.json').exists():
            checked=subprocess.run([sys.executable,str(out/'producer/transitionbench/verifier.py'),str(folder)],capture_output=True,text=True)
            v=json.loads(checked.stdout)
            manifest=read(folder/'manifest.json');spec=manifest['experiment']
            requests=[json.loads(x) for x in (folder/'requests.jsonl').read_text().splitlines()]
            offered_bytes=(out/(name+'-offered.jsonl')).read_bytes()
            offered=[json.loads(x) for x in offered_bytes.splitlines()]
            params=manifest['policy_parameters']
            initial=plan['target'] if trial['policy']=='candidate_reference' else plan['source']
            command=read(out/(name+'-initial-process.json'))['command']
            contract=(params['trial']==trial and params['protocol_sha256']==planhash and
                params['offered_sha256']==hashlib.sha256(offered_bytes).hexdigest() and
                manifest['versions']['code_revision']==sourcehash and params['initial_config']==initial and
                manifest['configurations']==plan['configurations'] and
                int(command[command.index('--max-num-batched-tokens')+1])==plan['configurations'][initial]['max_num_batched_tokens'] and
                ('--enable-prefix-caching' in command)==plan['configurations'][initial]['prefix_caching'] and
                len(offered)==len(requests) and all((a['request_id'],a['scheduled_s'],a['workload_class'],a['prefix_group'])==
                    (b['request_id'],b['scheduled_s'],b['workload_class'],b['prefix_group']) for a,b in zip(offered,requests)))
            events=[json.loads(x) for x in (folder/'transitions.jsonl').read_text().splitlines()]
            if events:
                command=read(out/(name+'-replacement-process.json'))['command'] if (out/(name+'-replacement-process.json')).exists() else []
                contract &= bool(command and ('--enable-prefix-caching' in command)==plan['configurations'][plan['target']]['prefix_caching'] and
                    int(command[command.index('--max-num-batched-tokens')+1])==plan['configurations'][plan['target']]['max_num_batched_tokens'])
            good=[r for r in requests if qualified(r,spec)]
            assert len(good)==v['recomputed']['qualified']
            injection=spec['workload']['injection_s']
            windows=[dict(start_s=s,offered=sum(s<=r['scheduled_s']<min(s+10,injection) for r in requests),
                qualified=sum(s<=r['scheduled_s']<min(s+10,injection) for r in good)) for s in range(0,math.ceil(injection),10)]
            completions=sorted(r['completed_s'] for r in good)
            result.update(status='VALID' if checked.returncode==0 and contract else 'INVALID',
                qualified=len(good),offered=len(requests),injection_s=injection,observation_s=spec['observation_s'],
                offered_sha256=params['offered_sha256'],transitions=events,windows=windows,
                final_20s_cohort_rate=sum(r['scheduled_s']>=injection-20 for r in good)/20,
                cumulative_1s=[bisect_right(completions,s) for s in range(math.floor(spec['observation_s'])+1)],
                quality_failures=sum(r['termination']=='complete' and not r['quality_valid'] for r in requests),
                max_dispatch_lag_s=max((r['scheduling_lag_s'] or 0 for r in requests),default=0),contract_matched=bool(contract))
            raw_by_name[name]=(requests,good)
        results.append(result)
    pairs=[]
    for scenario in sorted({r['scenario'] for r in results}):
        for seed in sorted({r['seed'] for r in results if r['scenario']==scenario}):
            rows={r['policy']:r for r in results if r['seed']==seed and r['scenario']==scenario and r['status']=='VALID'}
            if 'keep' not in rows:
                continue
            baseline=rows['keep']
            for policy,r in rows.items():
                if policy=='keep':continue
                assert baseline['offered_sha256']==r['offered_sha256'], 'Unmatched offered population'
                curve=[a-b for a,b in zip(r['cumulative_1s'],baseline['cumulative_1s'])]
                completed=max((e['at_s'] for e in r['transitions'] if e['state']=='COMPLETE'),default=0)
                starts=[e['at_s'] for e in r['transitions'] if e['state']=='STOPPING']
                recovery=None
                if starts and completed:
                    for t in range(math.ceil(completed),len(curve)-30):
                        if curve[t]>0 and min(curve[t:])>=0:
                            recovery=t;break
                pair=dict(scenario=scenario,seed=seed,policy=policy,baseline='keep',
                    difference=r['qualified']-baseline['qualified'],fraction=(r['qualified']/baseline['qualified']-1) if baseline['qualified'] else None,
                    baseline_qualified=baseline['qualified'],policy_qualified=r['qualified'],
                    observed_sustained_repayment_at_s=recovery,
                    repayment_after_switch_s=(recovery-min(starts)) if recovery is not None else None,
                    repayment_interpretation='Observed bound after declared readiness completion with a nonnegative remaining tail; may be later than the first positive cumulative crossing.',
                    resolution_s=1,minimum_observed_nonnegative_tail_s=30,delta_curve_1s=curve)
                if starts and 'candidate_reference' in rows:
                    ref=rows['candidate_reference'];start=min(starts)
                    candidate_good=raw_by_name[ref['name']][1];moving_good=raw_by_name[r['name']][1]
                    pair['candidate_relative_deficit']=sum(x['completed_s']>=start for x in candidate_good)-sum(x['completed_s']>=start for x in moving_good)
                pairs.append(pair)
    result=dict(status=read(out/'status.json')['state'],planned=len(plan['trials']),
        valid=sum(r['status']=='VALID' for r in results),rows=results,pairs=pairs,
        limitations=['Single local GPU, recorded desktop background; not dual-GPU rollout.',
            'Already-installed candidate is a separate initial-state reference, not a cost-free feasible migration.',
            'Exact marker correctness is not broad semantic task quality.',
            'No replayed curve is passed off as live policy execution. Repayment is observed only inside the recorded horizon.'])
    (out/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(status=result['status'],valid=result['valid'],planned=result['planned'],
        rows=[{k:r.get(k) for k in ('name','status','qualified','offered','final_20s_cohort_rate')} for r in results],
        pairs=[{k:v for k,v in p.items() if k!='delta_curve_1s'} for p in pairs]),indent=2))
    return result

if __name__=='__main__':
    analyze(ROOT/'outputs/transitionbench/reports'/sys.argv[1])
