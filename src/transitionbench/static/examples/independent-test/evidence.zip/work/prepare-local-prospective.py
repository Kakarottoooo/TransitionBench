"""Freeze a prospective replication before any new GPU observations exist."""
import hashlib
import json
from pathlib import Path
import time
import sys

from transitionbench.sdk import Client

ROOT = Path(__file__).resolve().parent.parent
REPORTS = ROOT / 'outputs/transitionbench/reports'
VERSION = sys.argv[1] if len(sys.argv) > 1 else 'v1'
assert VERSION in ('v1', 'v2', 'v3', 'v4')
SUFFIX = '' if VERSION == 'v1' else '-' + VERSION
OUT = REPORTS / ('deployment-prospective-' + VERSION)
NAME = 'local-cache-prospective-' + VERSION
assert not (REPORTS / NAME).exists(), 'Never reuse a measurement directory'
OUT.mkdir(exist_ok=False)
old = json.loads((REPORTS / 'local-cache-calibration-v1/protocol.json').read_text())
plan = {k: v for k, v in old.items() if k != 'trials'}
plan.update(id=NAME, max_runtime_s=3300,
    producer_snapshot='outputs/transitionbench/reports/local-cache-calibration-v1/producer/transitionbench',
    origin='Prospective replication: forecasts and endpoints frozen before new seeds are collected.',
    scope='Nine same-scope homogeneous trials; 20/40/120 second observation windows are not three new workload scenarios.')
orders = [('keep', 'candidate_reference', 'forced'), ('forced', 'keep', 'candidate_reference'),
          ('candidate_reference', 'forced', 'keep')]
seeds = {'v1': (7901,7902,7903), 'v2': (7911,7912,7913), 'v3': (7921,7922,7923), 'v4': (7931,7932,7933)}[VERSION]
if VERSION == 'v4':
    plan['record_prestart_resources'] = True
plan['trials'] = [dict(name=f'prospective-{seed}-{policy}', seed=seed, split='test',
    scenario='shared-prefix-prospective', policy=policy, switch_at_s=10,
    phases=old['trials'][0]['phases']) for seed, order in zip(seeds, orders) for policy in order]
# The same producer really executes: do not falsify code revision to bypass comparability.
digest = hashlib.sha256()
for path in sorted((ROOT / plan['producer_snapshot']).glob('*.py')):
    digest.update(path.name.encode()); digest.update(path.read_bytes())
manifest = json.loads((REPORTS / 'local-cache-calibration-v1/calibration-7701-keep/manifest.json').read_text())
assert manifest['versions']['code_revision'] == 'sha256:' + digest.hexdigest()
request = json.loads((REPORTS / 'deployment-review-v1/long-review.json').read_text())['request']
client = Client('http://127.0.0.1:8776')
forecast_ids = {}
for horizon, expected in ((20, 'WAIT'), (40, 'SWITCH' if VERSION in ('v3','v4') else 'WAIT'), (120, 'SWITCH')):
    frozen = client.propose({**request, 'horizon_s': horizon, 'advice_ttl_s': 3600},
                            idempotency_key=f'prospective-{VERSION}-{horizon}')
    assert frozen['decision']['action'] == expected, frozen['decision']
    if VERSION in ('v3','v4'):
        assert frozen['forecast_kind'] == 'paired-transition-curve-v1'
        assert frozen['decision']['gain_requests'] == {20:0,40:60,120:700}[horizon]
    forecast_ids[str(horizon)] = frozen['id']
    (OUT / f'forecast-{horizon}.json').write_text(json.dumps(frozen, indent=2))
(ROOT / f'work/local-cache-prospective{SUFFIX}-plan.json').write_text(json.dumps(plan, indent=2))
(OUT / 'measurement-plan.json').write_text(json.dumps(plan, indent=2))
protocol = dict(frozen_at_unix_s=time.time(), measurement_id=NAME, forecast_ids=forecast_ids,
    primary='At 120 seconds after actual restart begins, compare qualified completion gain with frozen 699-request forecast in all three independent paired seeds.',
    secondary=['Report all 20/40 second gains and whether WAIT misses positive work; no suppression of unfavorable observations.',
               'Report observed repayment at 1-second resolution, readiness, and error relative to 32.625 model seconds.',
               'Compare frozen selected action with keep and unconditional forced switch on the SAME matched traces; label offline decision-policy scoring, not a newly executed adaptive controller.',
               'Keep already-installed B reference visible; charge real restart downtime and all offered failures.',
               'Record campaign elapsed time (reservation-time upper proxy, not measured active GPU time), source calibration cost, and SDK review/feedback latency. No invented conversion from requests to money.'],
    acceptance=dict(completeness='All 9 planned trials and 3 pairs, no replaced seeds or cherry-picking.',
        engineering='Frozen forecast precedes collection; same context; API outcomes agree with independent raw arithmetic.',
        benefit='Positive 120-second switch-minus-keep in all 3 pairs establishes only repeated benefit in this scope.',
        prediction='Report signed and absolute errors for every pair; relative error denominator=max(1,abs(prediction)); no post hoc tolerance.',
        product='Superiority to immediate/simple strategies, new real workload scenarios, integration/adoption and net amortized measurement value remain unproven unless separately evidenced.'),
    constraints=['Single local RTX 3080 Ti; zero cloud GPU spend; preserve desktop noise.',
                 'Use exact archived calibration producer and engine launcher. Evaluate with installed v0.4.0.',
                 'No protocol changes after launch; preserve missing/failed groups; no selective reruns.',
                 'Advice is frozen for an experiment, not production execution authorization; expired outcomes remain explicitly labeled.'])
if VERSION == 'v2':
    protocol['replication_context'] = 'The prior v1 had one available pair and six startup memory failures during concurrent game activity. This is an entirely new full nine-trial queue with new seeds; original calibration, forecasts, endpoints and scoring stay unchanged. No pooling with v1 or selective replacement.'
if VERSION in ('v3','v4'):
    protocol['primary'] = 'Independently test repaired full-transition cumulative forecasts: 20s WAIT gain 0, 40s SWITCH gain 60, 120s SWITCH gain 700; report every paired error without post-hoc tolerance.'
    protocol['secondary'][1] = 'Report full-curve 1-second repayment versus 34s calibration checkpoint, first qualified service observation and declared warmup completion separately. No COMPLETE gate.'
    protocol['constraints'][1] = 'Use exact archived calibration producer and engine launcher. Evaluate with installed v0.4.1, paired-transition-curve-v1.'
    protocol['replication_context'] = 'v1/v2 are known development data for the method repair, not validation of the repaired rule. New seeds only; no pooling or selective replacement.'
    source = ROOT/'work/review-install-v040/Lib/site-packages/transitionbench'
    for name in ('proposals.py','metrics.py','policy.py','verifier.py'):
        shutil_target = OUT/'evaluator-source'/name
        shutil_target.parent.mkdir(exist_ok=True)
        shutil_target.write_bytes((source/name).read_bytes())
if VERSION == 'v4':
    protocol['replication_context'] = 'New complete independent replication after v3 startup resource contention. No decision tuning, no pooling with v3, no favorable seed replacement. Engine flags and workload unchanged.'
    protocol['resource_observation'] = 'Read-only pre-start GPU and process-group snapshot plus 5-second Windows GPU-process samples. Measurement overhead during a real switch remains charged. No new memory gating, adaptive warmup, or user process termination.'
(OUT / 'prospective-protocol.json').write_text(json.dumps(protocol, indent=2))
files = sorted(p for p in OUT.rglob('*') if p.is_file())
(OUT / 'freeze-sha256.json').write_text(json.dumps({p.relative_to(OUT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}, indent=2))
print(json.dumps(dict(status='FROZEN', forecasts=forecast_ids, planned=9, producer_sha256=digest.hexdigest())))
