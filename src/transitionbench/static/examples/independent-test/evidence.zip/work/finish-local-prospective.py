"""Close the frozen trial using public SDK and independent raw-event arithmetic."""
import hashlib
import json
import math
from pathlib import Path
import shutil
import subprocess
import time
import sys
import zipfile

from transitionbench.sdk import Client

ROOT = Path(__file__).resolve().parent.parent
REPORTS = ROOT / 'outputs/transitionbench/reports'
VERSION = sys.argv[1] if len(sys.argv) > 1 else 'v1'
assert VERSION in ('v1', 'v2', 'v3', 'v4')
SUFFIX = '' if VERSION == 'v1' else '-' + VERSION
OUT = REPORTS / ('deployment-prospective-' + VERSION)
RUN = REPORTS / ('local-cache-prospective-' + VERSION)
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
save = lambda p, v: p.write_text(json.dumps(v, ensure_ascii=False, indent=2), encoding='utf-8')

def raw_good(folder):
    manifest = read(folder / 'manifest.json')
    spec = manifest['experiment']
    rows = [json.loads(x) for x in (folder / 'requests.jsonl').read_text().splitlines() if x]
    good = sorted(r['completed_s'] for r in rows if r['termination'] == 'complete'
        and r['quality_valid'] and r['output_chars'] > 0 and r['completed_s'] is not None
        and r['first_content_s'] is not None and r['completed_s'] <= spec['observation_s']
        and r['completed_s']-r['scheduled_s'] <= spec['slo']['e2e_s']
        and r['first_content_s']-r['scheduled_s'] <= spec['slo']['first_content_s'])
    return good

def main():
    started = time.monotonic()
    freeze = read(OUT / 'freeze-sha256.json')
    assert all(hashlib.sha256((OUT / name).read_bytes()).hexdigest() == sha for name, sha in freeze.items())
    protocol = read(OUT / 'prospective-protocol.json')
    plan, state = read(RUN / 'protocol.json'), read(RUN / 'status.json')
    assert state['state'] in ('COMPLETE', 'PARTIAL') and 'ended_unix_s' in state
    assert protocol['frozen_at_unix_s'] < state['started_unix_s']
    assert plan == read(OUT / 'measurement-plan.json')
    wrapper = read(ROOT / f'work/local-cache-prospective{SUFFIX}-wallpaper.json')
    assert wrapper['resume_command_sent'], 'Wait for wrapper finally before closing'
    groups = [read(p)['pid'] for p in RUN.glob('*-process.json')]
    check = """import json,socket,subprocess
groups=set(GROUPS)
rows=subprocess.check_output(['ps','-eo','pid,pgid,args'],text=True).splitlines()[1:]
active=[r.strip() for r in rows if int(r.split(None,2)[1]) in groups]
with socket.socket() as s:
 s.settimeout(2); listening=s.connect_ex(('127.0.0.1',18870))==0
print(json.dumps(dict(active_owned_groups=active,port_18870_listening=listening)))
""".replace('GROUPS', repr(groups))
    # Capture WSL diagnostics: inherited stderr becomes a terminating NativeCommandError
    # under the PowerShell watcher's Stop preference, even when WSL exits successfully.
    probe = subprocess.run(['wsl','-d','Ubuntu-48G','--','python3','-c',check],
        capture_output=True, text=True, check=True)
    cleanup = json.loads(probe.stdout)
    cleanup['wsl_probe_stderr'] = probe.stderr
    assert not cleanup['active_owned_groups'] and not cleanup['port_18870_listening']
    cleanup.update(wrapper=wrapper, checked_unix_s=time.time(), processes_killed_by_check=0)
    save(OUT / 'cleanup.json', cleanup)
    analysis = read(RUN / 'analysis.json')
    complete = analysis['valid'] == 9 and state['state'] == 'COMPLETE'
    result = dict(status='COMPLETE' if complete else 'INCOMPLETE', planned=9, valid=analysis['valid'],
        gpu_campaign_wall_s=state['ended_unix_s']-state['started_unix_s'], cloud_gpu_spend_usd=0,
        all_offered=sum(r.get('offered', 0) for r in analysis['rows']), comparisons=[],
        limitations=protocol['constraints'] + [protocol['acceptance']['product'],
            'Short horizons are prefixes of sustained traces, not new brief-burst or stable workload executions.',
            'Offline action scoring is computed from separate matched trials, not a live adaptive policy.',
            'Entire campaign wall time is an upper reservation-time proxy, not measured active GPU time.',
            'No operator adoption, production counterfactual or amortized monetary ROI is established.'])
    valid_names = {r['name'] for r in analysis['rows'] if r['status'] == 'VALID'}
    paired_seeds = [seed for seed in sorted({t['seed'] for t in plan['trials']})
        if all(t['name'] in valid_names for t in plan['trials'] if t['seed'] == seed)]
    result['complete_pair_seeds'] = paired_seeds
    result['missing_or_invalid_units'] = [r for r in analysis['rows'] if r['status'] != 'VALID']
    # Preserve incomplete campaign status; never suppress a remaining complete triplet.
    if paired_seeds:
        client = Client('http://127.0.0.1:8776')
        before = time.monotonic()
        ids = [client.import_evidence(RUN / t['name'])['bundle_id'] for t in plan['trials'] if t['seed'] in paired_seeds]
        result['sdk_import_s'] = time.monotonic()-before
        save(OUT / 'outcome-imports.json', dict(bundle_ids=ids))
        for horizon in (20, 40, 120):
            forecast = read(OUT / f'forecast-{horizon}.json')
            before = time.monotonic()
            outcome = client.observe(forecast['id'], ids, idempotency_key=f'prospective-{VERSION}-outcome-{horizon}')
            save(OUT / f'outcome-{horizon}.json', outcome)
            result.setdefault('sdk_feedback_s', {})[str(horizon)] = time.monotonic()-before
            if outcome['status'] != 'COMPARABLE':
                result['status'] = 'NOT_COMPARABLE'
                result.setdefault('issues', {})[str(horizon)] = outcome['issues']
                continue
            for pair in outcome['pairs']:
                seed = pair['seed']
                dirs = {t['policy']: RUN / t['name'] for t in plan['trials'] if t['seed'] == seed}
                current, moving, candidate = [raw_good(dirs[k]) for k in ('keep','forced','candidate_reference')]
                events = [json.loads(x) for x in (dirs['forced'] / 'transitions.jsonl').read_text().splitlines() if x]
                start = next(e['at_s'] for e in events if e['state'] == 'STOPPING')
                ready = next(e['at_s'] for e in events if e['state'] == 'COMPLETE') - start
                def net(t):
                    return sum(start <= x <= start+t for x in moving)-sum(start <= x <= start+t for x in current)
                curve = [net(t) for t in range(horizon+1)]
                floor = 0 if forecast['forecast_kind'] == 'paired-transition-curve-v1' else ready
                repayment = next((t for t in range(horizon+1) if t >= floor and curve[t] > 0 and min(curve[t:]) >= 0), None)
                assert curve[-1] == pair['observed_net_requests']
                assert repayment == pair['observed_payback_after_switch_s']
                assert curve == [x['net_requests'] for x in pair['curve']]
                predicted = forecast['decision']['gain_requests']
                action = forecast['decision']['action']
                selected = curve[-1] if action == 'SWITCH' else 0
                result['comparisons'].append(dict(seed=seed, horizon_s=horizon, action=action,
                    predicted_net=predicted, measured_switch_minus_keep=curve[-1],
                    error=curve[-1]-predicted, relative_absolute_error=abs(curve[-1]-predicted)/max(1,abs(predicted)),
                    declared_transition_complete_s=ready, repayment_s=repayment,
                    payback_definition=pair.get('payback_definition','legacy_post_complete'),
                    model_break_even_s=forecast['decision']['break_even_s'],
                    selected_minus_keep=selected, selected_minus_always_switch=selected-curve[-1],
                    already_B_minus_keep=sum(start <= x <= start+horizon for x in candidate)-sum(start <= x <= start+horizon for x in current)))
        result['independent_raw_arithmetic'] = ('NOT_COMPARABLE' if result['status']=='NOT_COMPARABLE'
            else 'PASS' if complete else 'PASS_ON_AVAILABLE_PAIRS')
    else:
        result['independent_raw_arithmetic'] = 'NO_COMPLETE_PAIRS'
    calibration = read(REPORTS / 'local-cache-calibration-v1/status.json')
    result['existing_calibration_wall_s'] = calibration['ended_unix_s']-calibration['started_unix_s']
    result['analysis_wall_s'] = time.monotonic()-started
    save(OUT / 'result.json', result)
    lines = ['# 事前部署建议：独立实测核验', '', f"状态：{result['status']}；有效组 {analysis['valid']}/9。",
        f"本次本地采集耗时 {result['gpu_campaign_wall_s']/60:.1f} 分钟；新增云 GPU 费用 $0。已有云盘费用不包含在内。", '',
        '协议、20/40/120 秒预测和源码在新数据采集前冻结；未选择性重跑。', '',
        '| 种子 | 窗口秒 | 建议 | 预测净增 | 实测切换−保持 | 误差 | 实测回本秒 | 建议−直接切换 |',
        '|---|---:|---|---:|---:|---:|---:|---:|']
    for r in result['comparisons']:
        lines.append(f"| {r['seed']} | {r['horizon_s']} | {r['action']} | {r['predicted_net']:g} | {r['measured_switch_minus_keep']} | {r['error']:g} | {r['repayment_s']} | {r['selected_minus_always_switch']} |")
    lines += ['', '上述短窗口是持续流量轨迹的前缀；不能宣称新执行了短暂突发或稳定负载。策略比较是配对实测上的离线动作计分。',
        '收益使用全部 offered 请求中的严格质量/SLO 合格完成数。APC 是 vLLM 已有能力；本项目核验部署决定与代价。',
        f"评估不是免费：历史校准约 {result['existing_calibration_wall_s']/60:.1f} 分钟，本轮约 {result['gpu_campaign_wall_s']/60:.1f} 分钟，能否跨部署复用到回本还需业务频率与资源价格。", '',
        '下一步：先审阅全部预测误差及简单策略比较，决定建议模型是否需要修正；不以正收益替代预测准确性或客户采用证明。']
    (OUT / 'result.zh-CN.md').write_text('\n'.join(lines)+'\n', encoding='utf-8')
    # Add a new evidence package, never overwrite the historical release/studies.
    package = ROOT / f'outputs/TransitionBench-prospective-{VERSION}-evidence.zip'
    assert not package.exists(), 'Preserve the previous archive; investigate before rerunning closure'
    inputs = [p for base in (OUT, RUN) for p in base.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']
    inputs += [ROOT/'work'/name for name in ('prepare-local-prospective.py','finish-local-prospective.py','analyze-local-switch-study.py','run-local-switch-plan.ps1')]
    if VERSION == 'v4':
        inputs += [ROOT/'work'/name for name in ('local-cache-prospective-v4-resources.jsonl','local-cache-prospective-v4-wallpaper.json')]
    # Include the original forecast inputs as well as new outcomes: no external raw-data dependency.
    baseline_ids = {bid for p in read(OUT/'forecast-120.json')['request']['pairs']
                    for role, bid in p.items() if role in ('current','candidate','transition')}
    for bid in sorted(baseline_ids):
        inputs += [p for p in (REPORTS/'deployment-review-v1/bundles'/bid).iterdir() if p.is_file()]
    inputs.append(ROOT/'outputs/transitionbench/scripts/verify_proposal_arithmetic.py')
    hashes = {str(p.relative_to(ROOT)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
    with zipfile.ZipFile(package, 'w', zipfile.ZIP_DEFLATED) as z:
        for p in inputs:z.write(p,str(p.relative_to(ROOT)).replace('\\','/'))
        z.writestr('manifest-sha256.json',json.dumps(hashes,indent=2))
    with zipfile.ZipFile(package) as z:
        assert set(z.namelist()) == set(hashes) | {'manifest-sha256.json'}
        assert all(hashlib.sha256(z.read(name)).hexdigest()==sha for name,sha in hashes.items())
    sha = hashlib.sha256(package.read_bytes()).hexdigest()
    package.with_suffix('.zip.sha256').write_text(sha+'  '+package.name+'\n')
    save(OUT/'archive-receipt.json',dict(path=str(package),sha256=sha,verified_members=len(hashes),bytes=package.stat().st_size))
    print(json.dumps(dict(status=result['status'],valid=analysis['valid'],archive_sha256=sha)))

if __name__=='__main__':main()
