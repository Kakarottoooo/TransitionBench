Format projection of existing TransitionBench RTX 3080 Ti measurements, NOT an independent external collector or customer integration.
9 calibration and 9 independent held-out trials; this conversion adds no GPU measurements. Original timestamps, losses, request IDs, SLO and quality results are preserved. Read docs/external-logs.md in TransitionBench 0.4.3.
